import '#template/js/checkout'
import './custom-js/checkout'

window.ecomPaymentApps = [1250, 113537, 1251, 108091]
// window.ecomRecommendationsType = 'related'

window.__customGTMVariantRegex = /\s[^\s]+( zero a[ç|c][ú|u]car)?$/i
window.__sendGTMExtraPurchaseData = true
